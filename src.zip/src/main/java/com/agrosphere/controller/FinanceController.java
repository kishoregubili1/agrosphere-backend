package com.agrosphere.controller;

import com.agrosphere.dto.response.ApiResponse;
import com.agrosphere.entity.FinanceTransaction;
import com.agrosphere.entity.Tenant;
import com.agrosphere.enums.TransactionType;
import com.agrosphere.repository.FinanceTransactionRepository;
import com.agrosphere.repository.TenantRepository;
import com.agrosphere.util.AuthUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/farmer/finance")
@RequiredArgsConstructor
public class FinanceController {

    private final FinanceTransactionRepository repo;
    private final TenantRepository tenantRepository;
    private final AuthUtil authUtil;

    @GetMapping
    public ResponseEntity<?> getAll(@RequestParam(required=false) String type,
                                     @RequestParam(required=false) String category,
                                     @RequestParam(required=false) String from,
                                     @RequestParam(required=false) String to) {
        Tenant tenant = tenantRepository.findById(authUtil.getCurrentTenantId()).orElseThrow();
        List<FinanceTransaction> list = repo.findByTenantOrderByTransactionDateDesc(tenant);
        if (type != null && !type.isBlank())
            list = list.stream().filter(t -> t.getType().name().equals(type)).toList();
        if (category != null && !category.isBlank())
            list = list.stream().filter(t -> category.equals(t.getCategory())).toList();
        if (from != null && !from.isBlank()) { LocalDate d = LocalDate.parse(from);
            list = list.stream().filter(t -> t.getTransactionDate() != null && !t.getTransactionDate().isBefore(d)).toList(); }
        if (to != null && !to.isBlank()) { LocalDate d = LocalDate.parse(to);
            list = list.stream().filter(t -> t.getTransactionDate() != null && !t.getTransactionDate().isAfter(d)).toList(); }
        return ResponseEntity.ok(ApiResponse.success(list));
    }

    @GetMapping("/summary")
    public ResponseEntity<?> summary() {
        Long tid = authUtil.getCurrentTenantId();
        BigDecimal inc = repo.sumByTenantAndType(tid, TransactionType.INCOME);
        BigDecimal exp = repo.sumByTenantAndType(tid, TransactionType.EXPENSE);
        if (inc == null) inc = BigDecimal.ZERO;
        if (exp == null) exp = BigDecimal.ZERO;
        BigDecimal profit = inc.subtract(exp);
        BigDecimal margin = inc.compareTo(BigDecimal.ZERO) > 0 ?
            profit.multiply(BigDecimal.valueOf(100)).divide(inc, 1, RoundingMode.HALF_UP) : BigDecimal.ZERO;
        return ResponseEntity.ok(ApiResponse.success(Map.of(
            "totalIncome", inc, "totalExpense", exp, "netProfit", profit, "profitMargin", margin)));
    }

    @GetMapping("/monthly")
    public ResponseEntity<?> monthly() {
        List<Object[]> rows = repo.monthlyBreakdown(authUtil.getCurrentTenantId());
        List<Map<String,Object>> result = new ArrayList<>();
        for (Object[] r : rows) {
            Map<String,Object> m = new LinkedHashMap<>();
            m.put("month", r[0]); m.put("monthDate", r[1]);
            m.put("income", r[2]); m.put("expense", r[3]);
            result.add(m);
        }
        return ResponseEntity.ok(ApiResponse.success(result));
    }

    @GetMapping("/by-category")
    public ResponseEntity<?> byCategory() {
        List<Object[]> rows = repo.sumByCategory(authUtil.getCurrentTenantId());
        List<Map<String,Object>> result = new ArrayList<>();
        for (Object[] r : rows) {
            Map<String,Object> m = new LinkedHashMap<>();
            m.put("category", r[0]); m.put("income", r[1]); m.put("expense", r[2]);
            result.add(m);
        }
        return ResponseEntity.ok(ApiResponse.success(result));
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody FinanceTransaction req) {
        Tenant tenant = tenantRepository.findById(authUtil.getCurrentTenantId()).orElseThrow();
        req.setTenant(tenant);
        if (req.getTransactionDate() == null) req.setTransactionDate(LocalDate.now());
        return ResponseEntity.ok(ApiResponse.success(repo.save(req), "Transaction added"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        repo.deleteById(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Deleted"));
    }
}
